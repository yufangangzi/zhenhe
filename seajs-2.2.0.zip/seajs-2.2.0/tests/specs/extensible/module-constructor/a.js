define(function(require, exports, mod) {

  exports.filename = mod.getFilename()

});
