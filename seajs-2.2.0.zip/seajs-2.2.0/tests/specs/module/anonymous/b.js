define('./anonymous/b.js', [], { name: 'b' });
