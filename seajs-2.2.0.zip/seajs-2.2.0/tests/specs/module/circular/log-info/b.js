define(function(require, exports) {
  exports.name = 'b'
  exports.c = require('./c')
});
