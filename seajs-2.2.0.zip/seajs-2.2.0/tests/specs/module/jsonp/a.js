define(
    {
      name: 'a'
    }
);