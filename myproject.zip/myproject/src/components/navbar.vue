<style>
	.index-footer-new {
	    height: 60px;
	    line-height: 60px;
	    -webkit-box-flex: 3;
	    background: #F7F7F7;
	    border-top: 1px solid #ddd;
	    position: fixed;
	    width: 100%;
	    bottom: 0;
	    z-index: 2;
	    line-height: 20px;
	    font-size: 14px;
	}
	.index-footer-new div {
	    text-align: center;
	    -webkit-box-flex: 1;
	    -webkit-box-pack: center;
	    position: relative;
	    text-align: center;
	    padding-top: 2px;
	    width: 33.33%;
	    height: 60px;
	    float: left;
	}
  .index-footer-one{
		margin: 0 auto;
    display: block;
    background-image: url(http://t10.tianlaikge.com/picter/shop/lib/img/home-dj.png);
    background-size: 22px;
    background-position: 50% 20%;
    background-repeat: no-repeat;
  }
  .index-footer-detwo{
    margin: 0 auto;
    display: block;
    background-image: url(http://t10.tianlaikge.com/picter/shop/lib/img/dd-wdj.png);
    background-size: 22px;
    background-position: 50% 20%;
    background-repeat: no-repeat;
  }
  .index-footer-dethr{
    margin: 0 auto;
    display: block;
    background-image: url(http://t10.tianlaikge.com/picter/shop/lib/img/shou-wdj.png);
    background-size: 22px;
    background-position: 50% 20%;
    background-repeat: no-repeat;
  }
  .index-footer-new span {
    line-height: 80px;
	}
	.index-footer-new div i {
	    width: 1px;
	    height: 40px;
	    background: #D0D0D0;
	    display: block;
	    position: absolute;
	    right: 0;
	    top: 10px;
	}
</style>
<template>
   <div id="navbar" class="index-footer-new">
      <div class="index-footer-one"><span>首页</span><i></i></div>
      <div class="index-footer-one"><span>订单</span><i></i></div>
      <div class="index-footer-one"><span>售后</span><i></i></div>
   </div>
</template>

<script>
	export default{

	}
</script>