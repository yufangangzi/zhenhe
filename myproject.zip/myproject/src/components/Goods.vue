<style scoped>	
	@import "../assets/css/mui.min.css";
	@import "../assets/css/style.css";
    .mui-input-row p {
        float: left;
        width: 35px;
        margin-bottom: 0;
        padding-left: 0;
        border: 0;
        padding: 0 5px;
        text-align: center;
        border: 1px solid #ccc;
        border-radius: 10px;
        line-height: 33px;
        margin: 5px 0;
    }

    .mui-input-row .mui-btn {
        /*	    font-family: 'Helvetica Neue',Helvetica,sans-serif;
                line-height: 1.1;
                float: right;
                width: 15%;
                padding: 10px 15px;*/
    }

    .Good-user-info {
        position: relative;
    }

    select {
        font-size: 14px;
        height: auto;
        margin-top: 1px;
        border: 0 !important;
        background-color: #fff;
        padding: 4px 2px;
    }

    .mui-input-select {
        position: relative;
        float: left;
        line-height: 46px;
        width: 40px
    }

    .mui-input-row-new {
        position: relative;
        height: 46px;
        border-bottom: 1px solid rgba(152, 152, 152, 0.2);
        margin-left: 10px;
        clear: left;
        overflow: hidden;
    }

    .mui-input-row-new select {
        font-size: 14px;
        padding: 2px;
    }

    .mui-input-row-new label ~ input {
        float: left;
        width: 50%;
        border: 0;
        font-size: 14px;
        line-height: 46px;
        height: 46px;
    }

    .mui-input-content {
        float: left;
        line-height: 46px;
    }

    .mui-input-content:after {
        font-family: Muiicons;
        font-size: inherit;
        text-decoration: none;
        color: #bbb;
        -webkit-font-smoothing: antialiased;
        content: '\e581';
    }
    .Good-product img{
    	display: block;
    	width: 100%;
    }
	.visible{
		display: none !important;
	}
</style>
<template>
	<div id="details" class="container">
		<div :class="{'visible':boolean,'spinner-log':true}">
		    <div class="spinner">
		        <div class="circle1 circle"></div>
		        <div class="circle2 circle"></div>
		        <div class="circle3 circle"></div>
		        <div class="circle4 circle"></div>
		        <div class="circle5 circle"></div>
		        <div class="circle6 circle"></div>
		        <div class="circle7 circle"></div>
		        <div class="circle8 circle"></div>
		        <div class="circle9 circle"></div>
		        <div class="circle10 circle"></div>
		        <div class="circle11 circle"></div>
		        <div class="circle12 circle"></div>
		    </div>
		</div>
		<div class="content Good-box" style="display: block;">
		    <div class="float-div">商品已抢光，此商品为预售商品，预计7-15日后发货</div>
		    <div class="Good-list-time1">
		        <div class="Good-header">
		            <div class="Good-header-pic">
		                <div class="Good-header-pic-img">
		                    <img id="picImg" src="http://t10.tianlaikge.com/picter/shop/lib/img/MC-1/001_2.jpg" alt="">
		                </div>
		            </div>
		            <div class="Good-header-text">
		                <p class="Good-Name mui-ellipsis-2">商品名称：<span id="GoodsName">芒果天籁K歌智能麦克风MC-1</span></p>
		
		                <p class="Good-Money mui-ellipsis2">商品价格：￥<span id="GoodsMoney">899.00</span></p>
		                <p class="Good-Money mui-ellipsis2" id="remark" style="display: none;">赠：<span id="sent"></span></p>
		                <!--<p class="Good-Money mui-ellipsis2"> 颜色：<span id="soundCard_colors"></span></p>-->
		            </div>
		        </div>
		    </div>
		    <div class="Good-list-time2" style="height: 45px; display: none;" id="help">
		        <div class="Good-Num">
		            <div class="mui-input-row mui-table-view-cell" style="padding-left: 12px;">
		                <a id="help_a" class="mui-navigate-right" href="help.html">
		                    如何激活会员
		                </a>
		            </div>
		        </div>
		    </div>
		    <div class="Good-list-time2" style="height: 45px" id="select_colorcolor">
		        <div class="Good-Num">
		            <div class="mui-input-row mui-table-view-cell" style="padding-left: 12px;">
		                <a id="select_color_a" class="mui-navigate-right" href="#soundCard">
		                    颜色选择：<span id="soundCard_colors">灰色</span>
		                </a>
		            </div>
		        </div>
		    </div>
		    <!--<div class="Good-list-time2" style="height: 45px" id="express">-->
		    <!--<div class="Good-Num">-->
		    <!--<div class="mui-input-row mui-table-view-cell" style="padding-left: 12px;">-->
		    <!--<a class="mui-navigate-right" href="express.html">-->
		    <!--物流说明-->
		    <!--</a>-->
		    <!--</div>-->
		    <!--</div>-->
		    <!--</div>-->
		    <div class="Good-list-time2">
		        <div class="Good-Num">
		            <div class="mui-input-row">
		                <label class="mui-ellipsis">购买数量</label>
		
		                <div class="mui-numbox" data-numbox-min="1" data-numbox-max="100">
		                    <button class="mui-btn mui-btn-numbox-minus" type="button" disabled="">-</button>
		                    <input id="inputNum" class="mui-input-numbox" type="number" pattern="[0-9]*">
		                    <button class="mui-btn mui-btn-numbox-plus" type="button">+</button>
		                </div>
		            </div>
		        </div>
		    </div>
		    <div id="Good-list-time3" class="Good-list-time3" style="">
		        <div class="Good-price">
		            <div class="Good-price-Money">￥<span class="NumMoney">899</span>.00+运费：￥<input disabled="disabled" id="Freight" value="0" style="background:none;width: 50px;border: none;font-size: 14px;">
		            </div>
		            <div class="Good-price-red">需支付<span class="NumMoney">899</span>.00</div>
		        </div>
		        <!--<div id="express" class="Good-Num" style="border-top: 1px solid rgba(152, 152, 152, 0.2);">-->
		        <!--<div class="mui-input-row mui-table-view-cell" style="padding-left: 12px;">-->
		        <!--<a class="mui-navigate-right" href="express.html">-->
		        <!--物流说明-->
		        <!--</a>-->
		        <!--</div>-->
		        <!--</div>-->
		    </div>
		    <form id="GoodsInputList">
		        <div class="Good-list-time4">
		            <div class="Good-user-info">
		                <!--				<div class="mui-input-select">
		                                <label class="" href="#"></label>
		                                    <select name="select" id="telCode" >
		                                        <option value="86" selected="true">+86&nbsp;大陆</option>
		                                        <option value="852">+852&nbsp;香港特区</option>
		                                        <option value="853">+853&nbsp;澳门特区</option>
		                                        <option value="886">+886&nbsp;台湾地区</option>
		                                    </select>
		                                </div>-->
		                <div class="mui-input-row">
		                    <label>收货人姓名：</label>
		                    <input id="userId" type="text" onblur="BlurFun()" name="请填写您的姓名" class="mui-input" placeholder="请填写您的姓名">
		                </div>
		                <div class="mui-input-row-new">
		                    <label style="float: left;line-height: 46px;">手机号码：</label>
		                    <div class="mui-input-select">
		                        <label class="" href="#">
		                            <select name="select" id="telCode">
		                                <option value="86" selected="true">+86&nbsp;&nbsp;&nbsp;大陆</option>
		                                <option value="852">+852&nbsp;&nbsp;香港</option>
		                                <option value="853">+853&nbsp;&nbsp;澳门</option>
		                                <option value="886">+886&nbsp;&nbsp;台湾</option>
		                            </select>
		                        </label>
		                    </div>
		                    <div class="mui-input-content"></div>
		                    <input id="userTel" type="tel" name="请填写您的手机号" maxlength="11" class="mui-input" placeholder="请填写您的手机号" pattern="[0-9]*">
		                </div>
		                <div class="mui-input-row" id="showCityPicker3">
		                    <label>选择地区：</label>
		                    <input type="text" id="cityPicker3" readonly="" name="请选择地区" class="mui-input" placeholder="请选择地区">
		                    <!--<div id='cityResult3' class="mui-ellipsis"></div>-->
		                </div>
		            </div>
		        </div>
		        <div class="Good-list-time5">
		            <div class="Good-user-DataList">
		                <div class="mui-input-row" style=" height:80px;">
		                    <label>详细地址：</label>
		                    <!--<input id="userAddr" type="text" name="" class="mui-input" placeholder="请填写您的详情地址">-->
		                    <textarea id="userAddr" style="height:70px;" rows="3" maxlength="200" placeholder="请填写您的详细地址"></textarea>
		                </div>
		                <div class="mui-input-row" style=" height:80px;">
		                    <label>给卖家留言：</label>
		                    <!--<input type="text" class="mui-input-clear" placeholder="小小的脚印！">-->
		                    <textarea id="userTextarea" style="height:70px;" rows="3" maxlength="200" placeholder="卖家留言(选填)"></textarea>
		                </div>
		                <div class="mui-input-row">
		                    <label>邮政编码：</label>
		                    <input id="userPostCode" type="tel" name="请填写您的邮编" maxlength="6" class="mui-input" placeholder="请填写您的邮编(选填)" pattern="[0-9]*">
		                </div>
		            </div>
		        </div>
		    </form>
		
		    <div class="Good-list-time6" id="userFaid">
		        <div class="Good-else">
		            <span><input id="Good_else" type="text" value="其他：" disabled="disabled"></span>
		            <input type="hidden" id="faPiaoInput" value="0"><!-- 0不开发票，1开发票 -->
		            <div class="mui-switch" id="faPiaoSelect" data-switch="1">
		                <div class="mui-switch-handle"></div>
		            </div>
		        </div>
		    </div>
		    <div class="Good-list-time7" id="useInvoice" style="display: none;">
		        <input type="hidden" id="useInvoiceInput" value="0"><!-- 0个人，1公司 -->
		        <div class="useInvoice">
		            <ul class="mui-table-view mui-table-view-radio">
		                <li class="mui-table-view-cell mui-selected" data-type="0">
		                    <a class="mui-navigate-right">
		                        个人
		                    </a>
		                </li>
		                <li class="mui-table-view-cell" data-type="1">
		                    <a class="mui-navigate-right">
		                        公司
		                    </a>
		                </li>
		                <div class="mui-input-row">
		                    <label>发票内容：</label>
		                    <input type="text" class="mui-input" readonly="" disabled="" value="麦克风">
		                </div>
		                <div class="mui-input-row">
		                    <label>发票抬头：</label>
		                    <input id="useInvoiceText" type="text" name="useInvoice" class="mui-input" placeholder="请填写您的发票抬头" disabled="disabled">
		                </div>
		            </ul>
		        </div>
		    </div>
			<div class="Good-fromBtn details-footer" id="fromBtn" style="display: block;" @click="doAction">
			    <div style="background-color: rgb(78, 186, 77);">提交订单</div>
			</div>
		</div>
	</div>
</template>
<script>
	import axios from "axios"
	import App from "../assets/js/app.js"
	
	export default {
	    data(){
	        return {
		        switch1: false,
		        products:{
		        	productNo:this.$route.query.productNo,
		        },
		        httpUrl:App.httpUrl,
		        boolean:false,
		        Datas:[],
		        popupVisible:false
	        }  
	    },
	    mounted:function(){
	    	this.loadMore();
	    },
	    methods:{
			loadMore:function(){
		 	    axios.get(this.httpUrl +"/product/product?productNo=" + this.products.productNo)
		 	    .then(function(res){
			 	    console.log(res)
			 	    if(res.statusText == "OK"){
		                this.Datas = res.data.data;
		                this.boolean = true;
		                console.log(this.Datas);
			 	  	}else{
			 	  		//console.log(res)
			 	  	}
		 	    }.bind(this))
		 	    .catch(function(err){
		 	  	console.log(err)
		 	    });
			},
			doAction: function(event){
				if(event.target.parentNode.id == "fromBtn"){
					this.$router.push('SelectGoods');
				}
				//this.$router.push('help');
			},
	        doClick: function(){
	        	this.popupVisible = true;
	        }
	    }
	}
</script>