<style scoped>	
	@import "../assets/css/mui.min.css";
	@import "../assets/css/style.css";
    .mui-input-row p {
        float: left;
        width: 35px;
        margin-bottom: 0;
        padding-left: 0;
        border: 0;
        padding: 0 5px;
        text-align: center;
        border: 1px solid #ccc;
        border-radius: 10px;
        line-height: 33px;
        margin: 5px 0;
    }

    .mui-input-row .mui-btn {
        /*	    font-family: 'Helvetica Neue',Helvetica,sans-serif;
                line-height: 1.1;
                float: right;
                width: 15%;
                padding: 10px 15px;*/
    }

    .Good-user-info {
        position: relative;
    }

    select {
        font-size: 14px;
        height: auto;
        margin-top: 1px;
        border: 0 !important;
        background-color: #fff;
        padding: 4px 2px;
    }

    .mui-input-select {
        position: relative;
        float: left;
        line-height: 46px;
        width: 40px
    }

    .mui-input-row-new {
        position: relative;
        height: 46px;
        border-bottom: 1px solid rgba(152, 152, 152, 0.2);
        margin-left: 10px;
        clear: left;
        overflow: hidden;
    }

    .mui-input-row-new select {
        font-size: 14px;
        padding: 2px;
    }

    .mui-input-row-new label ~ input {
        float: left;
        width: 50%;
        border: 0;
        font-size: 14px;
        line-height: 46px;
        height: 46px;
    }

    .mui-input-content {
        float: left;
        line-height: 46px;
    }

    .mui-input-content:after {
        font-family: Muiicons;
        font-size: inherit;
        text-decoration: none;
        color: #bbb;
        -webkit-font-smoothing: antialiased;
        content: '\e581';
    }
    .Good-product img{
    	display: block;
    	width: 100%;
    }
	.visible{
		display: none !important;
	}
	.Good-box{
		position: relative;
	}
	
    .selectGoods-fromBtn div{
	    position: fixed;
	    bottom: 0;
	    z-index: 2;
	    background: #4eba4d;
	    width: 100%;
	    height: 50px;
	    color: #fff;
	    font-size: 20px;
	    line-height: 50px;
	    text-align: center;
    }	
</style>
<template>
<div id="details" class="container">
	<div :class="{'visible':boolean,'spinner-log':true}">
	    <div class="spinner">
	        <div class="circle1 circle"></div>
	        <div class="circle2 circle"></div>
	        <div class="circle3 circle"></div>
	        <div class="circle4 circle"></div>
	        <div class="circle5 circle"></div>
	        <div class="circle6 circle"></div>
	        <div class="circle7 circle"></div>
	        <div class="circle8 circle"></div>
	        <div class="circle9 circle"></div>
	        <div class="circle10 circle"></div>
	        <div class="circle11 circle"></div>
	        <div class="circle12 circle"></div>
	    </div>
	</div>
	<div class="Good-box">
	    <div class="float-div">商品已抢光，此商品为预售商品，预计7-15日后发货</div>
	    <div class="Good-list-time1">
	        <div class="Good-header">
	            <div class="Good-header-pic">
	                <div class="Good-header-pic-img">
	                    <img id="picImg" src="http://t10.tianlaikge.com/picter/shop/lib/img/MC-1/001_2.jpg" alt="">
	                </div>
	            </div>
	            <div class="Good-header-text">
	                <p class="Good-Name mui-ellipsis-2">商品名称：<span id="GoodsName">芒果天籁K歌智能麦克风MC-1</span></p>
	
	                <p class="Good-Money mui-ellipsis">商品价格：￥<span id="GoodsMoney">899.00</span><span style="margin-left: 5px" id="buyCount"></span><span id="totalPrice">合计：899.00</span></p>
	                <p class="Good-Money mui-ellipsis2"> 颜色：<span id="soundCard_colors">灰色</span></p>
	            </div>
	        </div>
	    </div>
	    <div class="Good-list-time4" style="height: 100%;margin-top: 10px;">
	        <div class="selectGood-user-info">
	            <div class="mui-input-row">
	                <div>姓名：<span id="userName">12</span></div>
	            </div>
	            <div class="mui-input-row">
	                <div>电话：<span id="userTel">15623423423</span></div>
	            </div>
	            <div class="mui-input-row selectGood-Dizhi-box">
	                <div style="display: -webkit-box;">地址：<span class="selectGood-Dizhi" id="userAddr">北京,北京市,东城区 2123</span></div>
	            </div>
	        </div>
	    </div>
	    <div class="selectGoods-pay">
	        <h5 class="mui-content-padded">支付方式</h5>
	        <ul class="mui-table-view mui-table-view-radio">
	            <li class="mui-table-view-cell mui-selected" id="weixin" data-type="1" style="display: block;">
	                <a class="mui-navigate-right">
	                    <span><img src="http://t10.tianlaikge.com/picter/shop/lib/img/wx.png" alt=""></span>微信支付
	                </a>
	            </li>
	            <li class="mui-table-view-cell" id="zfb" data-type="3" style="display: block;">
	                <a class="mui-navigate-right">
	                    <span><img src="http://t10.tianlaikge.com/picter/shop/lib/img/zfb.png" alt=""></span>支付宝支付
	                </a>
	            </li>
	        </ul>
	    </div>
	    <div :class="{'selectGoods-fromBtn':true,'visible':boolean}">
	        <div id="selectBtn" data-type="1">微信支付</div>
	    </div>
	</div>
</div>
</template>
<script>
	export default{
		data(){
			return{
				boolean:false
			}
		},
		mounted:function(){
			this.boolean = true;
			setTimeout(function(){
				document.getElementsByClassName("selectGoods-fromBtn")[0].classList.remove('visible');
			},1000)
		},
		methods:{
			
		}
	}
</script>