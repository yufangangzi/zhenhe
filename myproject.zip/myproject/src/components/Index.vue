<style scoped>
  html, body {
  	margin: 0;
  	padding: 0;
  	border: 0;
  	background-color: #f4f2f2;
  } 	
  li{
  	list-style: none;
  }
  .content{
  	display: inline-block;
    width: 100%;
    padding-bottom: 70px;
  }
  .content ul{
		list-style-type: disc;
		-webkit-margin-before: 0;
		-webkit-margin-after: 0;
		-webkit-margin-start: 0;
		-webkit-margin-end: 0;
		-webkit-padding-start: 0;
		background-color: #fff;
  }
  .content li{
  	width: 50%;
  	float: left;
  	box-sizing: border-box;
  	padding: 10px;
  }
	.ivu-carousel-dots li {
	    position: relative ;
	    display: inline-block;
	    vertical-align: top;
	    text-align: center;
	    margin: 0 2px;
	    padding: 7px 0;
	    cursor: pointer;
	}
  .content img, .container img{
  	width: 100%;
  }
  .padding-10{
  	padding: 10px;
  }
	.clear:after{
		content:'';
		display:block;
		clear:both;
		height:0;
		overflow:hidden;
		visibility:hidden;
		}
	.clear{
		zoom:1;
		}	
	.mt-20{
		margin-top: 10px !important;
	}	
	.toview-2 img{
    border: 1px solid #ccc;
	}
	.mar-20{
		text-align: left;
		padding: 10px 10px 0 10px !important;
		width: 100% !important;
		box-sizing: border-box;
	}
	.toview-3-border{
		/*border-bottom: 1px solid #ccc;*/
	}
	.toview-3 li {
		position: relative;
		width: 100%;
		display: inline-block;
		border-bottom: 1px solid #ccc;
	}
	.toview-con{
		display: inline-block;
	}
	.toview-3 p {
		font-size: 13px;
	}
	.toview-3 img {
		width: 30%;
		float: left;
	}
	.toview-3 .productName{
		color: #666;
	}
	.toview-3 .remark{
		color: #999;
	}
	.toview-3 .productPrice{
		color: red;
	}
	.slider-container .mint-swipe {
	    color: #fff;
	    font-size: 30px;
	    text-align: center;
	    height: 180px;
	    padding-bottom: 10px;
	}
	.banner{
		height: 100%;
	}

</style>
<template>
   <div id="index" class="container">
	    <Carousel autoplay inside v-model="value2">
	        <Carousel-item v-for="item in banners">
	            <div class="demo-carousel"><img :src="item.imgUrl"></div>
	        </Carousel-item>
	    </Carousel>
	    <div class="content">
	      <ul class="toview-1 clear"> 	
	      	<li v-for="item in expression">
	      		<div>
	      			<img @click="doAction()" :src="item.imgUrl">
	      		</div>
	      	</li>
	      </ul>
	      <ul class="toview-2 mt-20 clear">
	      	<div v-html="toview_2" :class="{'mar-20':showclass}"></div>
	      	<!--<li style="text-align: left;margin: 20px 20px 0 20px">精品推荐</li>-->
	      	<li v-for="item in recommend">
	      		<div @click="doAction()">
	      			<img  :src="item.imgUrl">
	      		</div>
	      	</li>      	
	      </ul>   
	      <ul class="toview-3 mt-20 clear">
	      	<div v-html="toview_3" :class="{'mar-20':showclass}"></div>
	      	<!--<li style="text-align: left;margin: 20px 20px 0 20px">精品推荐</li>-->
	      	<li v-for="item in hardware" @click="doAction(item.productNo,item.productName,item.productPrice)" >
		      	<!--<div style=""><img @click="doAction()" :src="item.img"></div>-->
		      	<!--<div style="width: 30%;float: left;"><img @click="doAction()" :src="item.img"></div>-->
		        	<img :src="item.img">
		      	  <div class="toview-3-div" style="width: 60%;float: right;text-align: left;">
								<p v-html="item.productName" class="clear productName"></p>
								<p v-html="item.remark" class="clear remark"></p>
								<p v-html="item.productPrice" class="clear productPrice"></p>
							</div>
	      	</li>      	
	      </ul> 	
	      <div>
	      	 <p v-html="indexText[0]"></p>
	      	 <p v-html="indexText[1]"></p>
	      </div>
	      <navBar v-if="show"></navBar>
      </div>	
   </div>
</template>
<script> 
	import axios from "axios";
	import navBar from "./navbar.vue";
    import Data from "../assets/js/app.js";

	export default{
		data(){
			return{
		        isActive : [true,false],
		        expression : [],
		        recommend : [],
		        hardware : [],
		        banners : [],
		        indexText :[],
		        toview_2 : '',
		        toview_3 : '',
		        showclass : '',
		        mintswipe : '',
		        value2: 0,
		        httpUrl: Data.httpUrl,
		        show:'',
		        boolean:false
			}
		},
		beforeRouteLeave  (to, from, next) {
            if(this.boolean){
           	   next()
            }
		},
		watch: {
		   $route (Index) {
		     
		   }
		},
		components:{
			navBar
		},
	 	mounted:function(){
	 		isActive : [true,false];
		  	this.loadMore();	
		},
		methods:{
			COMMONFUN: function(){
			},
			loadMore: function(){ 
		        axios.get(this.httpUrl+'/product/indexProducts2?channel=TLKG18&clientType=Android&clientVersion=4.8.1')
				    .then(function(res) {
				  	console.log(res);
					  	for(var i=0;i<res.data.data.indexparam.length;i++){
						  	if(res.data.data.indexparam[i].name == "礼物商店" || res.data.data.indexparam[i].name == "表情商店"){
						  		  this.expression.push(res.data.data.indexparam[i]);
						  		  this.show = true;
						  	}else if(res.data.data.indexparam[i].name == '推荐' && res.data.data.indexparam[i].type == 1){
						  		  this.recommend.push(res.data.data.indexparam[i]);
						  		  this.toview_2 = '精品推荐';
						  		  this.showclass = true;
						  	}else if(res.data.data.indexparam[i].name == "bannner" && res.data.data.indexparam[i].type == 2){
						  		  this.banners.push(res.data.data.indexparam[i]);
						  		  this.boolean = true;
						  	} 
						}
					  	//document.getElementsByClassName('mint-swipe')[0].clientHeight = document.getElementsByClassName('mint-swipe-item')[0].
					  	for(var i=0;i<res.data.data.product.length;i++){
				  		  	  this.hardware.push(res.data.data.product[i]);
				  		  	  this.toview_3 = '硬件入口';
				  		  	  this.showclass = true;	 
				  		  	  this.indexText = ['如果有问题请联系客服','400-9191-888'];
					  	}  	
				    }.bind(this))
				    .catch(function (error){
				    console.log(error);
				});
		    },
			calculation: function(){
/*					setTimeout(function(){
										let length = document.getElementsByClassName('toview-3')[0].children.length - 1;
										let DivMax = document.getElementsByClassName('toview-3')[0].childNodes[2].clientHeight;
										for(var i=0;i<length;i++){
											  document.getElementsByClassName('toview-3-div')[i].style.marginTop = (DivMax - document.getElementsByClassName('toview-3-div')[i].clientHeight)/2 + 'px';
										}
					},5)*/
			},
		    doAction: function(productNo,productName,productPrice){ 
		   	   this.$router.push({ name: 'Details', query: { 'productNo': productNo, 'productName': productName, 'productPrice': productPrice}});
		    }
		},
	}
</script>