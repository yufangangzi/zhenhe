<style scoped>
  html, body {
  	margin: 0;
  	padding: 0;
  	border: 0;
  } 	
  li{
  	list-style: none;
  }
  .content{
  	display: inline-block;
    width: 100%;
  }
  .content ul{
	display: block;
	list-style-type: disc;
	-webkit-margin-before: 0;
	-webkit-margin-after: 0;
	-webkit-margin-start: 0;
	-webkit-margin-end: 0;
	-webkit-padding-start: 0;
  }
  .content li{
  	float: left;
  }
  .container img{
  	width: 100%;
  }
	.toview-3 li {
    position: relative;
    width: 100%;
    display: inline-block;
    border-bottom: 1px solid #ccc;
	}
	.details-time-title span{
		display: -webkit-box;
		font-size: 14px;
		line-height: 24px;
		    padding: 0 10px;
	}
	.details-time-color{
		display: -webkit-box;
		margin-top: 10px;
    padding: 0 10px;
	}
	.details-time-color span{
		text-align: left;
		font-size: 14px;
		line-height: 24px;
	}
	.orange{
		color: #fd7839;
	}
	.gray{
		color: #999;
	}
	.detalis-nav{
		width: 100%;
    display: -webkit-box;
    height: 40px;
    line-height: 40px;
    border-top: 1px solid #f3f3f3;
    border-bottom: 1px solid #f3f3f3;
    background: #fff;
    font-size: 14px;
	}
	.detalis-nav div {
    display: -webkit-box;
    -webkit-box-flex: 1;
    -webkit-box-pack: center;
    position: relative;
    background: #fff;
	}
	.detalis-nav div i {
    width: 90px;
    height: 2px;
    background: #2fb8fc;
    display: block;
    position: absolute;
    bottom: 0px;
    left: 50%;
    margin-left: -45px;
    display: none;
	}
	.detalis-nav-on {
    color: #2fb8fc;
	}	
	.details-right{
		display: none;
	}
	.details-footer {
	    position: fixed;
	    bottom: 0;
	    z-index: 2;
	    background: #4eba4d;
	    width: 100%;
	    height: 50px;
	    color: #fff;
	    font-size: 20px;
	    line-height: 50px;
	    text-align: center;
	}
	.visible{
		display: none !important;
	}
</style>
<template>
<div id="details" class="container">
	    <Carousel autoplay inside v-model="value2">
	        <Carousel-item v-for="item in Datas.productImgs">
	            <div class="demo-carousel"><img :src="item"></div>
	        </Carousel-item>
	    </Carousel>
    	<div class="content">
    		 <div class="details-time-title">
    		 	  <span v-html="Datas.productName"></span>
    		 	  <span :class="{'orange':true,'visible':boolean}">￥
    		 	  	<span v-html="Datas.productPrice"></span>
    		 	  </span>
    		 </div>
    		 <div class="details-time-color">
    		 	  <span :class="{'gray':true,'visible':boolean}">颜色：</span>
    		 	  <span v-for="item in Datas.colors"><span v-html="item"></span></span> 
    		 </div>
    		 <div class="details-img">
    		 	<div class="detalis-nav">
    		 	  <div :class="{'detalis-nav-on':true,'button':true,'visible':boolean}" @click="ClickButton">商品信息
    		 	  	<i style="display: block;"></i>
    		 	  </div>
    		 	  <div :class="{'button':true,'visible':boolean}" @click="ClickButton">咨询与售后
    		 	  	<i></i>
    		 	  </div>
    		 	</div>  	
            <div class="details-left">
            	  <li v-for="item in Datas.detailImgs">
            	  	  <img :src="item">
            	  </li>
            </div>
            <div class="details-right">
            	  <li v-for="item in Datas.serverImgs">
            	  	  <img :src="item">
            	  </li>
            </div>
    		 </div>
    		 <div :class="{'details-footer':true,'visible':boolean}" @click="doAction()">		 	
			    已售完
    		 </div>
    	</div> 
</div>
</template>
<script>
	import axios from "axios"
	import App from "../assets/js/app.js"
	export default{
		data(){
			return{
				products: {
					productNo:this.$route.query.productNo,
					productName:this.$route.query.productName,
					productPrice:this.$route.query.productPrice
				},
				httpUrl: App.httpUrl,
				Datas:[],
				value2:0,
				activeClass:'detalis-nav-on',
				boolean:true
			}
		},
	 	mounted:function(){
	 		this.loadMore();
		},
		methods:{
			loadMore:function(){
		 	  axios.get(this.httpUrl +"/product/getProductByNo?productNo=" + this.products.productNo)
		 	  .then(function(res){
		 	  	console.log(res)
		 	  	if(res.statusText == "OK"){
          this.Datas = res.data.data;
          this.boolean = false;
		 	  	}else{
		 	  		//console.log(res)
		 	  	}
		 	  }.bind(this))
		 	  .catch(function(err){
		 	  	console.log(err)
		 	  });
			},
			ClickButton:function(event){
		   	document.getElementsByClassName("button")[0].classList.remove('detalis-nav-on');
				document.getElementsByClassName("button")[1].classList.remove('detalis-nav-on');
				document.getElementsByClassName("button")[0].childNodes[1].style.display = "none";
				document.getElementsByClassName("button")[1].childNodes[1].style.display = "none";
				if(event.target == document.getElementsByClassName("button")[0]){	
					document.getElementsByClassName("details-left")[0].style.display = "block";
					document.getElementsByClassName("details-right")[0].style.display = "none";
					if(event.target.className =="detalis-nav-on"){
						return false;
					}else{
						event.target.classList.add('detalis-nav-on');
						event.target.childNodes[1].style.display = "block";
					}
				}else{
					document.getElementsByClassName("details-left")[0].style.display = "none";
					document.getElementsByClassName("details-right")[0].style.display = "block";
					if(event.target.className =="detalis-nav-on"){
						return false;
					}else{
						event.target.classList.add('detalis-nav-on');
						event.target.childNodes[1].style.display = "block";
					}
				}
			},
      doAction:function(){
      	this.$router.push({name:'Goods',query:{'productNo':this.products.productNo}});
      }
		},
	}
</script>