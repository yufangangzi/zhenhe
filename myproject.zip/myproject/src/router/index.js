import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/*Router.prototype.goBack = function () { 
	  alert()
　　this.isBack = true
　　window.history.go(-1)  
}*/




export default new Router({
  routes: [
    {
      path: '/',
      name: 'Index',
      component: require('@/components/Index.vue')
    },
    {
 	    path:'/Details',
 	    name:'Details',
 	    component: require('@/components/Details.vue'),
    },
    {
 	    path:'/Goods',
 	    name:'Goods',
 	    component: require('@/components/Goods.vue'),
    },
    {
 	    path:'/help',
 	    name:'help',
 	    component: require('@/components/help.vue'),
    },
    {
 	    path:'/SelectGoods',
 	    name:'SelectGoods',
 	    component: require('@/components/SelectGoods.vue'),
    }
  ]
})


/*export default new Router({
  routes: [
    {
      path: '/',
      name: 'Index',
      component: require('@/components/Index.vue'),
    },
    {
 	    path:'/Details',
 	    name:'Details',
 	    component:require('@/components/Details.vue'),
    }
  ]
})*/
