//var httpUrl = "http://www.tlkg.com/shop2";
// var httpUrl = "http://shoptest.audiocn.org/shop2";



export default{
	httpUrl:"http://shoptest.audiocn.org/shop2"
}





//var httpUrl = "http://localhost:8080/shop2";
/*var httpUrl = "http://"+location.host+"/shop2";

var templates = httpUrl + "/mobile/";
var templates2 = httpUrl + "/mobile/";
var useragent = navigator.userAgent;
function url(name) {   //获取url 地址传的数据
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return (r[2]);
    return "";
}
function $id(id) {
    var id = document.getElementById(id);
    return id;
}
function checkMobile() {
    var sMobile = $id("QueryTel").value;
    if (sMobile == "") {
        mui.alert("请输入手机号", '提示', function () {

        });
        return false
    } else if (!/^(13[0-9]|14[0-9]|15[0-9]|18[0-9]|17[0-9])\d{8}$/i.test(sMobile)) {
        mui.alert("不是完整的11位手机号或者正确的手机号", '提示', function () {

        });
        return false;
    }
    return true;
}

function code() {
    var codeS = $id("QueryCode");
    if (!checkMobile()) {
        return false;
    } else if (codeS.value == "") {
        mui.alert("请输入验证码", '提示', function () {

        });
        return false
    } else if (codeS.value.length != 6) {
        mui.alert("请输入正确的验证码", '提示', function () {

        });
        return false
    }
    return true;
}


function count_down(o) {
    var product = url("productNo"),
        userId = url("userid"),
        uuid = url("uuid"),
        channel = url("channel");
    var www_qsyz_net = /^[\d]{4}-[\d]{1,2}-[\d]{1,2}( [\d]{1,2}:[\d]{1,2}(:[\d]{1,2})?)?$/ig, str = '', conn, s;
    if (!o.match(www_qsyz_net)) {
        //alert('参数格式为2012-01-01[ 01:01[:01]].\r其中[]内的内容可省略');
        return false;
    }
    var sec = (new Date(o.replace(/-/ig, '/')).getTime() - new Date().getTime()) / 1000;
    if (sec > 0) {
        conn = '还有';
    } else {
        conn = '已过去';
        sec *= -1;
    }
    s = {'天': sec / 24 / 3600, '小时': sec / 3600 % 24, '分': sec / 60 % 60, '秒': sec % 60};
    for (i in s) {
        if (Math.floor(s[i]) > 0) str += Math.floor(s[i]) + i;
    }
    if (Math.floor(sec) == 0) {
        str = '0秒';
    }
    if (str == "0秒") {
        document.getElementById('detailsBtn').innerHTML = "立即购买";
        mui("#detailsBtn")[0].addEventListener("tap", function () {
            location.href = "Goods.html?productNo=" + product + "&userid=" + userId + "&uuid=" + uuid + "&channel=" + channel;
        })
        return false
    }

    document.getElementById('detailsBtn').innerHTML = "倒计时：" + str + "开抢";
    setTimeout(function () {
        count_down(o)
    }, 1000);
}

try {
    mui(".tab-index")[0].addEventListener("tap", function () {
        var locUrl = templates2 + "index.html?userid=" + url("userid") + "&uuid=" + url("uuid") + "&type=0&channel=" + url("channel");
        location.href = locUrl;
    });
    mui(".tab-order")[0].addEventListener("tap", function () {
        var locUrl = templates2 + "order.html?userid=" + url("userid") + "&uuid=" + url("uuid") + "&type=0&channel=" + url("channel");
        location.href = locUrl;
    });
    mui(".tab-after")[0].addEventListener("tap", function () {
        var locUrl = templates2 + "order.html?userid=" + url("userid") + "&uuid=" + url("uuid") + "&type=1&channel=" + url("channel");
        location.href = locUrl;
    });
} catch (e) {

}
function wxfxpublic(url) {
    mui.ajax(httpUrl + '/tool/wechatShare?url=' + encodeURIComponent(url), {
        dataType: 'json',//服务器返回json格式数据
        type: 'get',//HTTP请求类型
        timeout: 10000,//超时时间设置为10秒；
        success: function (data) {
            if (data.code == 1) {
                var wxData = data.weiXinShareVo;
                wx.config({
                    debug: false,
                    appId: wxData.appId,
                    timestamp: wxData.timestamp,
                    nonceStr: wxData.nonceStr,
                    signature: wxData.signature,
                    jsApiList: [
                        'checkJsApi',
                        'onMenuShareTimeline',
                        'onMenuShareAppMessage',
                        'onMenuShareQQ',
                        'onMenuShareWeibo',
                        'hideMenuItems',
                        'hideOptionMenu',
                        'hideAllNonBaseMenuItem'
                    ]
                });

            }
        },
        error: function (xhr, type, errorThrown) {
            //异常处理；
            console.log(type);
        }
    });
    wx.ready(function () {
        var wxdatas = {
            title: "天籁K歌 智能麦克风",
            desc: "“点击一下，秒变歌神！！！”",
            link: templates + "index.html",
            imgUrl: "http://t10.tianlaikge.com/picter/shop/lib/img/MC-1/001.jpg",
            trigger: function (res) {

            },
            success: function (res) {

            },
            cancel: function (res) {

            },
            fail: function (res) {

            }
        };

        wx.onMenuShareAppMessage(wxdatas);
        wx.onMenuShareTimeline(wxdatas);
        wx.onMenuShareQQ(wxdatas);
        wx.onMenuShareWeibo(wxdatas);

    });
}
function wxfxDetails(url) {
    mui.ajax(httpUrl + '/tool/wechatShare?url=' + encodeURIComponent(url), {
        dataType: 'json',//服务器返回json格式数据
        type: 'get',//HTTP请求类型
        timeout: 10000,//超时时间设置为10秒；
        success: function (data) {
            if (data.code == 1) {

                var wxData = data.weiXinShareVo;
                wx.config({
                    debug: false,
                    appId: wxData.appId,
                    timestamp: wxData.timestamp,
                    nonceStr: wxData.nonceStr,
                    signature: wxData.signature,
                    jsApiList: [
                        'checkJsApi',
                        'onMenuShareTimeline',
                        'onMenuShareAppMessage',
                        'onMenuShareQQ',
                        'onMenuShareWeibo',
                        'hideMenuItems',
                        'hideOptionMenu',
                        'hideAllNonBaseMenuItem'
                    ]
                });

            }
        },
        error: function (xhr, type, errorThrown) {
            //异常处理；
            console.log(type);
        }
    });
    wx.ready(function () {
        var wxdatas = {
            title: "天籁K歌 智能麦克风",
            desc: "“点击一下，秒变歌神！！！”",
            link: templates + "details.html?productNo=100003",
            imgUrl: "http://t10.tianlaikge.com/picter/shop/lib/img/MC-1/001.jpg",
            trigger: function (res) {

            },
            success: function (res) {

            },
            cancel: function (res) {

            },
            fail: function (res) {

            }
        };

        wx.onMenuShareAppMessage(wxdatas);
        wx.onMenuShareTimeline(wxdatas);
        wx.onMenuShareQQ(wxdatas);
        wx.onMenuShareWeibo(wxdatas);

    });
}
function isIos(){
    var useragent = navigator.userAgent;
    if (useragent.indexOf('iPhone') != -1) {
        return true;
    }
    return false;
}
function isAndroid(){
    var useragent = navigator.userAgent;
    if (useragent.indexOf('Android') != -1) {
        return true;
    }
    return false;
}

function iosVersion(){
    var useragent = navigator.userAgent;
    var reg=/OS \d_?\d?_?\d?/g;
    var a=reg.exec(useragent)[0].slice(2);
    a= a.split('_');
    a[0]+='.';
    return s=a.join('');
}
var app_init = {

    app_tlkg_title: function (title) {
        var json = {
            "type": "M_ZDY_TITLE",
            "content": {title: title},
            "callBack": "backFun"
        };
        if (isIos()) {
            if (iosVersion() >= 8) {
                window.webkit.messageHandlers.tlkgWKWebViewApp.postMessage(json);
                return false
            } else {
                tlkgJsModl.toview(json);
                return false
            }
        } else if (isAndroid()) {
            tlkgJsModl.toview(JSON.stringify(json));
            return false
        } else {
            alert("其他平台");
        }
    },
    app_UPPER_RIGHT: function (name) {
        var json = {
            "type": "M_ZDY_UPPER_RIGHT",
            "content": {
                name: name,
                url: "http://shopping.audiocn.org/shop_saler/myapp/templates/help_2.html"
            },
            "callBack": "backFun"
        };
        if (isIos()) {
            if (iosVersion() >= 8) {
                window.webkit.messageHandlers.tlkgWKWebViewApp.postMessage(json);
                return false
            } else {
                tlkgJsModl.toview(json);
                return false
            }
        } else if (isAndroid()) {
            tlkgJsModl.toview(JSON.stringify(json));
            return false
        } else {
            alert("其他平台");
        }
    }

};*/
